# University Inventory Management System

**Student Name:** Qaiser Rahman  
**Course:** ITS105 Programming Fundamentals  
**Institution:** National Academy of Professional Studies (NAPS)

## Project Overview

This console-based application simulates a University Inventory Management System used
to manage equipment, furniture, and lab assets across departments.

## Key Concepts Demonstrated

* Object-Oriented Programming (OOP)
* Inheritance and Polymorphism
* Abstract Classes
* Custom Exception Handling
* Arrays and Array Manipulation
* Decision Structures (if/else, switch)
* Loop Constructs (for, while, do-while, foreach)
* Menu-driven Console Application

## Learning Reflection

Through this project, I improved my understanding of Java class design, inheritance,
exception handling, and how real-world systems can be modelled using object-oriented
principles. I also gained confidence in structuring larger programs and integrating
multiple components into a single working system.

Developed by **Qaiser Rahman**.





**Introduction**



This dissertation is what I am submitting to complete my ITS102. It focuses on the design and deployment of a University Inventory Management System which is designed to mimic the process through which a higher education institution manages and monitors its assets. The system allows faculty and administrative staff to maintain equipment records, assign equipment to the staff, track availability and produce inventory reports. The project combines fundamental programming skills learned in the unit in a real-life situation.



**Project Structure**



The project architecture is a purposeful attempt to make the project a clear and modular structure to enhance the readability and maintainability. It consists of separate packages of models, managers and exceptions together with a primary application class that integrates all the components. This design is a good programming practice and it makes understanding, expanding and debugging easier.



**Lessons Learned**



The process of undertaking this unit has been very valuable and rewarding. Writing this project has been an eye opener and has solidified several of the most important concepts in programming. The main lessons that I have learned are:



\- Design and implementation of the classes using object oriented concepts of encapsulation, inheritance and polymorphism.

\- The importance of the role of control structures, loops and methods in building logical and efficient programs.

\- Why graceful handling of error is required via exception handling, and the importance of good code organisation in improving the general quality of the program.



**Conclusion**



To conclude, the given project has allowed me to be able to bring the theoretical knowledge obtained during the ITS102 unit into a tangible programming project. The development of the University Inventory Management System helped me to improve my understanding of the basics of Java and developed my problem-solving skills. All in all, the venture has been a learning experience, as it has strengthened my belief in the ability to create structured and functional software applications.

