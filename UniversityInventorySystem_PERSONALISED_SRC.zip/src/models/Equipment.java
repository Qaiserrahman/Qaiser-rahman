
package models;

public class Equipment extends InventoryItem {
    private String brand;
    private String assetId;
    private int warrantyMonths;
    private String category;

    public Equipment(String assetId, String name, String brand, String category, int warrantyMonths) {
        super(assetId, name, true);
        this.assetId = assetId;
        this.brand = brand;
        this.category = category;
        this.warrantyMonths = warrantyMonths;
    }

    public String getAssetId() { return assetId; }
    public String getBrand() { return brand; }
    public int getWarrantyMonths() { return warrantyMonths; }
    public String getCategory() { return category; }

    public void setWarrantyMonths(int warrantyMonths) {
        this.warrantyMonths = warrantyMonths;
    }

    @Override
    public String getItemType() {
        return "Equipment";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Equipment)) return false;
        Equipment other = (Equipment) obj;
        return assetId.equals(other.assetId);
    }

    @Override
    public String toString() {
        return super.toString() + 
               ", Brand=" + brand + 
               ", Category=" + category + 
               ", WarrantyMonths=" + warrantyMonths;
    }
}
