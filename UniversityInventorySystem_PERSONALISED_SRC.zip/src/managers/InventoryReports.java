
package managers;

import models.*;

public class InventoryReports {

    public void generateInventoryReport(InventoryItem[] items) {
        for (int i = 0; i < items.length; i++) {
            if (items[i] != null) {
                System.out.println(items[i]);
            }
        }
    }

    public void findExpiredWarranties(Equipment[] equipmentList) {
        int i = 0;
        while (i < equipmentList.length) {
            if (equipmentList[i] != null && equipmentList[i].getWarrantyMonths() <= 0) {
                System.out.println("Expired Warranty: " + equipmentList[i]);
            }
            i++;
        }
    }

    public void calculateUtilisationRate(StaffMember[] staffList) {
        for (StaffMember staff : staffList) {
            if (staff != null) {
                System.out.println(staff.getName() + " has " +
                        staff.getAssignedEquipmentCount() + " items assigned.");
            }
        }
    }

    public void generateMaintenanceSchedule(Equipment[] equipmentList) {
        int i = 0;
        do {
            if (i < equipmentList.length && equipmentList[i] != null) {
                System.out.println("Maintenance check scheduled for: " +
                        equipmentList[i].getAssetId());
            }
            i++;
        } while (i < equipmentList.length);
    }
}
