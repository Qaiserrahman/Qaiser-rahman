
package managers;

import models.*;
import exceptions.*;

public class InventoryManager {

    public void assignEquipment(StaffMember staff, Equipment equipment)
            throws EquipmentNotAvailableException, AssignmentLimitExceededException {

        if (!equipment.isAvailable()) {
            throw new EquipmentNotAvailableException("Equipment is currently unavailable.");
        }

        if (!staff.addAssignedEquipment(equipment)) {
            throw new AssignmentLimitExceededException("Staff member has reached assignment limit.");
        }

        equipment.setAvailable(false);
    }

    public void returnEquipment(StaffMember staff, String assetId) throws InventoryException {
        if (!staff.removeAssignedEquipment(assetId)) {
            throw new InventoryException("Equipment not assigned to this staff member.");
        }
    }

    public double calculateMaintenanceFee(Equipment equipment, int daysOverdue) {
        switch (equipment.getCategory()) {
            case "IT":
                return daysOverdue * 5.0;
            case "Lab":
                return daysOverdue * 10.0;
            default:
                return daysOverdue * 3.0;
        }
    }

    // Overloaded search methods
    public void searchEquipment(Equipment[] list, String name) {
        for (Equipment e : list) {
            if (e != null && e.getName().equalsIgnoreCase(name)) {
                System.out.println(e);
            }
        }
    }

    public void searchEquipment(Equipment[] list, String category, boolean availableOnly) {
        for (Equipment e : list) {
            if (e != null && e.getCategory().equalsIgnoreCase(category)) {
                if (!availableOnly || e.isAvailable()) {
                    System.out.println(e);
                }
            }
        }
    }

    public void searchEquipment(Equipment[] list, int minWarranty, int maxWarranty) {
        for (Equipment e : list) {
            if (e != null &&
                e.getWarrantyMonths() >= minWarranty &&
                e.getWarrantyMonths() <= maxWarranty) {
                System.out.println(e);
            }
        }
    }
}
