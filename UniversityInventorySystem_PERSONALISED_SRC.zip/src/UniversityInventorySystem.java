
import java.util.Scanner;
import models.*;
import managers.*;
import exceptions.*;

public class UniversityInventorySystem {

    static Equipment[] equipmentList = new Equipment[10];
    static StaffMember[] staffList = new StaffMember[5];

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        InventoryManager manager = new InventoryManager();
        InventoryReports reports = new InventoryReports();

        int choice;
        do {
            System.out.println("\n--- University Inventory System ---");
            System.out.println("1. Add Equipment");
            System.out.println("2. Register Staff");
            System.out.println("3. Assign Equipment");
            System.out.println("4. Return Equipment");
            System.out.println("5. Generate Reports");
            System.out.println("6. Exit");
            System.out.print("Choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            try {
                switch (choice) {
                    case 1:
                        addEquipment(sc);
                        break;
                    case 2:
                        registerStaff(sc);
                        break;
                    case 3:
                        manager.assignEquipment(staffList[0], equipmentList[0]);
                        System.out.println("Equipment assigned.");
                        break;
                    case 4:
                        manager.returnEquipment(staffList[0], equipmentList[0].getAssetId());
                        equipmentList[0].setAvailable(true);
                        System.out.println("Equipment returned.");
                        break;
                    case 5:
                        reports.generateInventoryReport(equipmentList);
                        break;
                }
            } catch (InventoryException e) {
                System.out.println("Error: " + e.getMessage());
            }

        } while (choice != 6);

        sc.close();
    }

    static void addEquipment(Scanner sc) {
        equipmentList[0] = new Equipment("EQ1", "Laptop", "Dell", "IT", 12);
        System.out.println("Sample equipment added.");
    }

    static void registerStaff(Scanner sc) {
        staffList[0] = new StaffMember(1, "Qaiser Rahman", "john@naps.edu.au");
        System.out.println("Sample staff registered.");
    }
}
